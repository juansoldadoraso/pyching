# pyching
I ching en python para gente avanzada
Leer el tao te king de lao tse.
http://libroesoterico.com/biblioteca/I-Ching/TaoTeKing-LaoTse-RH-Wilhem.pdf

Basado en i ching : http://libroesoterico.com/biblioteca/I-Ching/I-Ching-Libro_de_las_Mutaciones-r-h-wilhem.pdf
